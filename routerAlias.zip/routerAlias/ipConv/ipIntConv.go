package ipConv

import (
	"strings"
)

//16843009 -> 1.1.1.1
func Uint32ToString(u uint32) string {
	a := u & 255
	b := u & 65280 >> 8
	c := u & 16711680 >> 16
	d := u & 4278190080 >> 24
	return Uint32ToStringMap[d] + "." + Uint32ToStringMap[c] + "." + Uint32ToStringMap[b] + "." + Uint32ToStringMap[a]
}

//1.1.1.1 -> 16843009
func String2Uint32(s string) uint32 {
	sArray := strings.Split(s, ".")
	var res uint32 = 0
	res = String2Uint32Map[sArray[3]] + String2Uint32Map[sArray[2]]*256 + String2Uint32Map[sArray[1]]*65536 + String2Uint32Map[sArray[0]]*16777216
	return res
}
