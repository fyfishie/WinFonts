package main

import (
	"fmt"
	"math"
	"routerAlias/graph"
	"routerAlias/ipSameParse"
	"routerAlias/lib"
	"routerAlias/subGather"
	"time"
)

type IpList struct {
	IpList []int
}

type AliasPair struct {
	IpA int
	IpB int
}

var ipToDoTraceList = map[int]lib.TraceRoute{}
var ipSameTraceList = map[int]lib.TraceRoute{}

var ipToDoList = []int{}
var netBlockInPutChan chan ([]int)
var gatherByDivisionOutChan chan ([][]int)
var verifyTrace = map[int]lib.TraceRoute{}
var pingSet = map[int][]int{}
var antiAliasMap = map[int]lib.AntiAliasSet{}

func main() {
	test()
}

func test() {
	loadIpToDo(500000)
	loadIpSame()

	// fmt.Println(len(ipToDoTraceList))

	antiAliasSets := [][]int{}
	netBlockInPutChan = make(chan []int, 10)
	gatherByDivisionOutChan = make(chan [][]int, 100)
	netBlocks := divideIpList(ipToDoList)
	g := subGather.NewGather(netBlockInPutChan, gatherByDivisionOutChan)
	g.GatherRun(8)
	go func() {
		for _, netBlock := range netBlocks {
			netBlockInPutChan <- netBlock
		}
	}()

	for i := 0; i < len(netBlocks); i++ {
		antiAliasSet := <-gatherByDivisionOutChan
		antiAliasSets = append(antiAliasSets, antiAliasSet...)
	}
	fmt.Println(len(antiAliasSets))
	antiAliasMap := make(map[int]lib.AntiAliasSet)
	ipSameParse.AntiAliasSet2Map(antiAliasSets, antiAliasMap)

	distinct := map[int]bool{}
	ipSameParse.ParseOneTrace(ipToDoTraceList, antiAliasMap, distinct)
	ipSameParse.ParseOneTrace(ipToDoTraceList, antiAliasMap, distinct)
	fmt.Println(len(antiAliasMap))

	maxCorrelationIpPairs := getMaxCorrelationIpPairs(ipToDoList)
	fmt.Println(len(maxCorrelationIpPairs))

}

func Run() {
	loadIpSame()
	// loadIpToBeParsed()

	//非别名筛选
	antiAliasSets := [][]int{}
	netBlockInPutChan = make(chan []int, 10)
	gatherByDivisionOutChan = make(chan [][]int, 100)
	netBlocks := divideIpList(ipToDoList)
	g := subGather.NewGather(netBlockInPutChan, gatherByDivisionOutChan)
	g.GatherRun(100)
	go func() {
		for _, netBlock := range netBlocks {
			netBlockInPutChan <- netBlock
		}
	}()

	for i := 0; i < len(netBlocks); i++ {
		antiAliasSet := <-gatherByDivisionOutChan
		antiAliasSets = append(antiAliasSets, antiAliasSet...)
	}

	antiAliasMap := make(map[int]lib.AntiAliasSet)
	ipSameParse.AntiAliasSet2Map(antiAliasSets, antiAliasMap)
	ipSameParse.ParseEnd2(ipToDoTraceList, antiAliasMap)

	ipDistinctMap := map[int]bool{} //两个traceRoute集合有交集
	ipSameParse.ParseOneTrace(ipToDoTraceList, antiAliasMap, ipDistinctMap)
	ipSameParse.ParseOneTrace(ipSameTraceList, antiAliasMap, ipDistinctMap)

	//基于动态时延差聚类的初步别名推断
	maxCorrelationIpPairs := getMaxCorrelationIpPairs(ipToDoList)

	//别名验证
	aliasPairs := aliasVerify(maxCorrelationIpPairs)

	//通过传递关系进行最后处理
	aliasSets := aliasConnect(aliasPairs)
	fmt.Println(aliasSets)
}

//求极大连通子图*
func aliasConnect(aliasPairs [][]int) [][]int {
	g := graph.NewGraph()
	for _, pair := range aliasPairs {
		g.AddEdge(pair[0], pair[1])
	}
	return g.MaxConnectedSubGraph()
}

//别名验证
func aliasVerify(ipPairs map[int]int) [][]int {
	aliasPairs := [][]int{}
	for ipA, ipB := range ipPairs {
		if sameEnd2Router(ipA, ipB) {
			aliasPairs = append(aliasPairs, []int{ipA, ipB})
		} else if pingSame(ipA, ipB) {
			aliasPairs = append(aliasPairs, []int{ipA, ipB})
		}
	}
	return aliasPairs
}

func pingSame(ipA int, ipB int) bool {
	pingResA := pingSet[ipA]
	pingResB := pingSet[ipB]
	cmpLen := len(pingResA)
	if len(pingResB) < len(pingResA) {
		cmpLen = len(pingResA)
	}
	sameCount := 0
	for i := 0; i < cmpLen; i++ {
		if pingResA[i] == pingResB[i] {
			sameCount++
		}
	}
	return 5*sameCount > 4*cmpLen
	// sameCount           4
	//------------   >  --------
	//  cmpLen             5
}
func sameEnd2Router(ipA int, ipB int) bool {
	// traceA := verifyTrace[ipA]
	// traceB := verifyTrace[ipB]
	// return traceA.End2 == traceB.End2
	return true
}

//两两配对,内层循环起始下标从外层循环当前下标开始，避免AB BA都被计算*(两两配对自动去重已验证)
func getMaxCorrelationIpPairs(ipList []int) map[int]int {
	start := time.Now().Unix()
	now := start
	length := len(ipList)
	maxCorrelationMap := make(map[int]int)
	for indexA, ipA := range ipList {
		var maxCorrelation float64 = 0
		maxCorrelationIp := -1
		for indexB := indexA; indexB < length; indexB++ {
			now = time.Now().Unix()
			if now-start > 10 {
				start = now
				fmt.Printf("%v %v\n", indexA, indexB)
			}
			ipB := ipList[indexB]
			if aliasPossiable(ipA, ipB) {
				newCorrelation := getCorrelation(ipA, ipB)
				if newCorrelation > maxCorrelation {
					maxCorrelation = newCorrelation
					maxCorrelationIp = ipB
				}
			}
		}
		maxCorrelationMap[ipA] = maxCorrelationIp
	}
	return maxCorrelationMap
}
func aliasPossiable(ipA int, ipB int) bool {
	ipANotAlias, ok := antiAliasMap[ipA]
	if !ok {
		for _, ip := range ipANotAlias {
			if ip == ipB {
				return false
			}
		}
	}
	return true
}
func getCorrelation(ipA int, ipB int) float64 {
	RL := getRL(ipA, ipB)
	tA := getDelayGap(RL, ipA, ipToDoTraceList[ipA])
	tB := getDelayGap(RL, ipB, ipToDoTraceList[ipB])
	ipSameWithRL := getTraceWithRL(RL)
	ipSameDelayList := []float64{}
	for _, ipSame := range ipSameWithRL {
		delay := getDelayGap(RL, ipSame, ipSameTraceList[ipSame])
		ipSameDelayList = append(ipSameDelayList, delay)
	}
	var sum float64
	for _, ti := range ipSameDelayList {
		absSub := math.Abs(tA-ti) - math.Abs(tB-ti)
		sum += math.Sqrt(absSub * absSub)
	}
	return float64(len(ipSameWithRL)) / sum
}

func getTraceWithRL(RL int) (ipSameWithRL []int) {
	for ipSame, trace := range ipSameTraceList {
		for _, ip := range trace.Trace {
			if ip == RL {
				ipSameWithRL = append(ipSameWithRL, ipSame)
				break
			}
		}
	}
	return ipSameWithRL
}

func getDelayGap(RL int, ip int, trace lib.TraceRoute) float64 {
	var delayGap float64 = 0
	for i := len(trace.Trace) - 1; i > -1; i-- {
		if trace.Trace[i] == RL {
			delayGap = trace.Times[len(trace.Times)-1] - trace.Times[i]
		}
	}
	return delayGap
}

//非别名筛选，获取最近的共同路由
func getRL(ipA int, ipB int) int {
	traceA := ipToDoTraceList[ipA].Trace
	traceB := ipToDoTraceList[ipB].Trace
	sameRouter := -1
	for iA := len(traceA) - 1; iA >= 0; iA-- {
		for iB := len(traceB) - 1; iB >= 0; iB-- {
			if traceA[iA] == traceB[iB] {
				sameRouter = traceA[iA]
			}
		}
	}
	return sameRouter
}

//以/20为一个单位对所有待测ip进行划分*
func divideIpList(ipListAll []int) [][]int {
	res := [][]int{}
	segMax := 0
	segMin := 0
	segMin = (ipListAll[0] / 1024) * 1024
	if (ipListAll[len(ipListAll)-1]+1)%1024 == 0 {
		segMax = ipListAll[len(ipListAll)-1]
	} else {
		segMax = ((ipListAll[len(ipListAll)-1])/1024)*1024 + 1023
	}
	leftEdge := segMin
	rightEdge := segMin + 1023
	ipList := []int{leftEdge, rightEdge}
	for i := 0; rightEdge <= segMax; i++ {
		if i == len(ipListAll) {
			res = append(res, ipList)
			break
		}
		if ipListAll[i] >= leftEdge && ipListAll[i] <= rightEdge {
			ipList = append(ipList, ipListAll[i])
		} else {
			if len(ipList) > 2 {
				res = append(res, ipList)
			}
			i--
			leftEdge += 1024
			rightEdge += 1024
			ipList = []int{leftEdge, rightEdge}
		}
	}
	return res
}
