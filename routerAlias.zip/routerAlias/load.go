package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"routerAlias/ipConv"
	"routerAlias/lib"
	"sort"
)

//{"ip":"223.70.222.0","results":[{"ttl":4,"status":11,"ip":"221.2.164.1","rtt":41094994},{"ttl":5,"status":11,"ip":"221.2.164.1","rtt":2830438}],"circle":true}
type pathInput struct {
	Ip      string `json:"ip"`
	Results []hop  `json:"results"`
	Circle  bool   `json:"circle"`
}

type hop struct {
	TTL    int    `json:"ttl"`
	Status int    `json:"status"`
	Ip     string `json:"ip"`
	Rtt    int    `json:"rtt"`
}

func loadIpSame() {
	fi, err := os.OpenFile("./db/trace/Beijing_ipsame_path.json", os.O_RDONLY, 0444)
	if err != nil {
		fmt.Println("error in load trace of ip same")
		os.Exit(1)
	}
	reader := bufio.NewReader(fi)
	for {
		line, _, err := reader.ReadLine()
		if err != nil {
			break
		} else {
			input := pathInput{}
			err := json.Unmarshal(line, &input)
			if err != nil {
				continue
			} else {
				if len(input.Results) > 0 {
					if input.Ip == input.Results[len(input.Results)-1].Ip {
						addInput(input, ipSameTraceList)
					}
				}
			}
		}
	}
}

func addInput(input pathInput, traceList map[int]lib.TraceRoute) {
	length := len(input.Results)
	trace := lib.TraceRoute{
		Start: int(ipConv.String2Uint32(input.Ip)),
		End:   int(ipConv.String2Uint32(input.Results[length-1].Ip)),
	}
	if length >= 2 {
		trace.End2 = int(ipConv.String2Uint32(input.Results[length-2].Ip))
	}
	for i := 0; i < length; i++ {
		trace.Trace = append(trace.Trace, int(ipConv.String2Uint32(input.Results[i].Ip)))
		trace.Times = append(trace.Times, float64(input.Results[i].Rtt))
	}
	traceList[trace.Start] = trace
}

// func loadIpListToBeParsed(from string) {
// 	ipListToBeParsed = *generateIp(20)
// }

func loadTraceForAliasVerify(from string) {
	// trace := lib.TraceRoute{}
}

func loadIpToDo(num int) {
	fi, err := os.OpenFile("./db/trace/Beijing_path.json", os.O_RDONLY, 0444)
	if err != nil {
		fmt.Println("error in load trace of ip same")
		os.Exit(1)
	}
	reader := bufio.NewReader(fi)
	count := 0
	for {
		line, _, err := reader.ReadLine()
		if err != nil {
			break
		} else {
			input := pathInput{}
			err := json.Unmarshal(line, &input)
			if err != nil {
				continue
			} else {
				if len(input.Results) > 0 {
					if input.Ip == input.Results[len(input.Results)-1].Ip {
						if count == num {
							break
						}
						addInput(input, ipToDoTraceList)
						ipToDoList = append(ipToDoList, int(ipConv.String2Uint32(input.Ip)))
					}
				}
			}
		}
	}
	sort.Ints(ipToDoList)
}
