package lib

type IIP int
type TraceRoute struct {
	Start int
	End   int
	End2  int
	Trace []int
	Times []float64
}

type AntiAliasSet []int
type IpList struct {
	IpList []int
}

type AliasPair struct {
	IpA int
	IpB int
}
type IpPair struct {
	Left  int
	Right int
	Next  *IpPair
}
type PingSet map[int][]float64
