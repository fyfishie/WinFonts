package main

import (
	"math/rand"
	"routerAlias/lib"
)

func generateIp(hostSeg int) *[]int {
	resMap := make(map[int]int, 100000)
	res := make([]int, 100000)
	netSeg := 32 - hostSeg
	net := (rand.Int() % int(lib.Square2[netSeg])) << hostSeg
	net = 3220176896
	for i := 0; i < 100000; i++ {
		host := (rand.Int() % int(lib.Square2[hostSeg]))
		ip := net + host
		_, ok := resMap[ip]
		if ok {
			i--
		} else {
			resMap[ip] = 1
			res[i] = ip
		}
	}
	return &res
}
