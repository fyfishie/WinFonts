package ipSameParse

import (
	"fmt"
	"routerAlias/lib"
)

func ParseEnd2(traceList map[int]lib.TraceRoute, resMap map[int]lib.AntiAliasSet) {
	countMap := map[int]lib.AntiAliasSet{}
	for _, trace := range traceList {
		if trace.Start == 1026657938 {
			fmt.Println("1")
		}
		if countMap[trace.End2] == nil {
			countMap[trace.End2] = lib.AntiAliasSet{trace.End}
		} else {
			countMap[trace.End2] = append(countMap[trace.End2], trace.End)
		}
	}
	for _, set := range countMap {
		for _, ip1 := range set {
			for _, ip2 := range set {
				if resMap[ip1] == nil {
					resMap[ip1] = lib.AntiAliasSet{ip2}
				} else {
					resMap[ip1] = append(resMap[ip1], ip2)
				}
			}
		}
	}

}

func ParseOneTrace(traceList map[int]lib.TraceRoute, resMap map[int]lib.AntiAliasSet, ipDistinctMap map[int]bool) {
	for _, trace := range traceList {
		_, ok := ipDistinctMap[trace.End]
		if !ok {
			for _, ip1 := range trace.Trace {
				for _, ip2 := range trace.Trace {
					if resMap[ip1] == nil {
						resMap[ip1] = lib.AntiAliasSet{ip2}
					} else {
						resMap[trace.End2] = append(resMap[trace.End2], trace.End)
					}
				}
			}
		}
	}
}

func AntiAliasSet2Map(sets [][]int, resMap map[int]lib.AntiAliasSet) {
	for _, set := range sets {
		for _, ip1 := range set {
			for _, ip2 := range set {
				if resMap[ip1] == nil {
					resMap[ip1] = lib.AntiAliasSet{ip2}
				} else {
					resMap[ip1] = append(resMap[ip1], ip2)
				}
			}
		}
	}
}
